package com.cg.banking.servlet;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
@WebServlet("/FundTransferServlet")
public class FundTransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BankingServices bankingServices=new BankingServicesImpl();
		Long accountNoTo=Long.parseLong(request.getParameter("accountNoTo"));
		Long accountNoFrom=Long.parseLong(request.getParameter("accountNoFrom"));
		float transferAmount=Float.parseFloat(request.getParameter("transferAmount"));
		int pinNumber=Integer.parseInt(request.getParameter("pinNumber"));
		boolean message=false;
		try {
				message=bankingServices.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber);
		} catch (InsufficientAmountException | AccountNotFoundException
				| InvalidPinNumberException | BankingServicesDownException
				| AccountBlockedException e) {
			e.printStackTrace();
		}
		request.setAttribute("string1", "Hello1");
		if(message!=false)
		request.setAttribute("message","Fund has been transferred successfully");
		else
		request.setAttribute("message", "Some Problems has been occured.Try After Some time.");
		RequestDispatcher dispatcher= request.getRequestDispatcher("fundTransferPage.jsp");
		dispatcher.forward(request, response);
	}

}
